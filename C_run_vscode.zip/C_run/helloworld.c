#include <stdio.h>

int main(void)
{
    printf("asdf");

#ifdef aaa
sadf = 1
#endif

    getchar();
    return 0;
}